Crecent Client 1.21.1
=====================

Single-player utility mod loader for Minecraft Java 1.21.1 (Fabric).

WHAT'S IN THIS FOLDER
---------------------
  Freebuff.Injector.exe   The loader UI (this is what you run)
  Freebuff.dll            The client - MUST stay next to the exe
  README.txt              This file

QUICK START
-----------
  1. Keep both files together in any folder.
  2. Run Freebuff.Injector.exe.
  3. Sign in with any valid-looking email + password
     (accounts are cosmetic - nothing is sent or stored beyond a
     remembered email in %APPDATA%\Crecent\session.dat).
  4. Launch Minecraft 1.21.1 (single player world), then press
     Inject in the loader (or wait for the auto-scan).
  5. In game, press INSERT to open the client menu.

MODULES
-------
  Toggle modules in the loader (Modules page) or in the in-game
  menu. Loader toggles are saved to
  %APPDATA%\Freebuff\config.json and apply live in game within a
  few seconds while the in-game menu is closed.
  Green dot on a module = currently active in the running game.

TIPS
----
  - If the preflight check shows SeDebugPrivilege as failed, run the
    loader as administrator.
  - Wall Hit: aim your crosshair at the target through a wall and
    hold attack. Works up to ~3 blocks (more with Reach enabled).
  - The window is resizable (drag the edges) and has a fullscreen
    button in the title bar.

FILES THE LOADER/CLIENT USE
---------------------------
  %APPDATA%\Freebuff\config.json    module toggles + UI settings
  %APPDATA%\Freebuff\status.json    live in-game state (heartbeat)
  %APPDATA%\Crecent\loader.log      debug log (enable in Client settings)
  loader.ini (next to the exe)      loader preferences

FOR PERSONAL / SINGLE-PLAYER USE ONLY.
